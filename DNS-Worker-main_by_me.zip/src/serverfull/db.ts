/**
 * @file db.ts
 * @description SQLite D1Database adapter and automatic schema migration runner for Serverfull mode.
 */

import fs from 'node:fs';
import path from 'node:path';
import { Buffer } from 'node:buffer';
import { DatabaseSync } from 'node:sqlite';
import { D1Database, D1PreparedStatement, D1Result, D1ExecResult, D1DatabaseSession } from '@cloudflare/workers-types';
import { getPackageRoot } from './config';

/**
 * Normalizes input parameter values to primitive types safely bindable by SQLite and node:sqlite.
 *
 * SQLite natively supports: NULL, INTEGER, REAL, TEXT, and BLOB.
 * node:sqlite accepts:
 *   - null
 *   - number / bigint
 *   - string
 *   - Buffer / Uint8Array (BLOB)
 *
 * In older Node.js versions (< v26.8.0) and Bun, node:sqlite rejects raw ArrayBuffer instances
 * with "TypeError: Provided value cannot be bound to SQLite parameter (ERR_INVALID_ARG_TYPE)".
 * It also rejects boolean and undefined values.
 *
 * This normalizer converts:
 *   - undefined -> null
 *   - boolean -> 1 or 0
 *   - ArrayBuffer -> Buffer.from(val)
 *   - ArrayBufferView (Uint8Array, DataView, etc.) -> Buffer.from(val.buffer, val.byteOffset, val.byteLength)
 */
export function toSqliteParam(val: unknown): any {
  if (val === null || val === undefined) {
    return null;
  }
  if (typeof val === 'boolean') {
    return val ? 1 : 0;
  }
  if (val instanceof ArrayBuffer) {
    return Buffer.from(val);
  }
  if (ArrayBuffer.isView(val)) {
    return Buffer.from(val.buffer, val.byteOffset, val.byteLength);
  }
  return val;
}

/**
 * Normalizes values returned by SQLite into standard Cloudflare D1 types.
 *
 * node:sqlite returns BLOB columns as Uint8Array instances. Cloudflare Workers D1
 * returns BLOB columns as ArrayBuffer instances. Converting Uint8Array to ArrayBuffer
 * guarantees 100% API parity with Workers D1.
 */
export function fromSqliteValue(val: unknown): any {
  if (val instanceof Uint8Array) {
    return val.buffer.slice(val.byteOffset, val.byteOffset + val.byteLength);
  }
  return val;
}

export function fromSqliteRow<T = unknown>(row: Record<string, any>): T {
  const normalized: Record<string, any> = {};
  for (const [k, v] of Object.entries(row)) {
    normalized[k] = fromSqliteValue(v);
  }
  return normalized as T;
}

export class NodeD1PreparedStatement implements D1PreparedStatement {
  private params: any[] = [];

  constructor(
    public readonly db: DatabaseSync,
    public readonly sql: string
  ) {}

  bind(...values: any[]): D1PreparedStatement {
    this.params = values.map(toSqliteParam);
    return this as unknown as D1PreparedStatement;
  }

  async first<T = unknown>(colName?: string): Promise<T | null> {
    try {
      const stmt = this.db.prepare(this.sql);
      const row = stmt.get(...this.params) as Record<string, any> | undefined;
      if (!row) return null;
      if (colName) {
        return fromSqliteValue(row[colName] ?? null) as T;
      }
      return fromSqliteRow<T>(row);
    } catch (err: any) {
      console.warn(`[SQLite D1] Query error in first(): ${err.message}\nSQL: ${this.sql}`);
      throw err;
    }
  }

  async all<T = unknown>(): Promise<D1Result<T>> {
    try {
      const stmt = this.db.prepare(this.sql);
      const rows = stmt.all(...this.params) as Record<string, any>[];
      const normalizedRows = rows.map(r => fromSqliteRow<T>(r));
      return {
        results: normalizedRows,
        success: true,
        meta: {
          duration: 0,
          size_after: 0,
          rows_read: rows.length,
          rows_written: 0,
          last_row_id: 0,
          changed_db: false,
          changes: 0
        }
      };
    } catch (err: any) {
      console.warn(`[SQLite D1] Query error in all(): ${err.message}\nSQL: ${this.sql}`);
      throw err;
    }
  }

  async run<T = unknown>(): Promise<D1Result<T>> {
    try {
      const stmt = this.db.prepare(this.sql);
      const result = stmt.run(...this.params);
      const changes = Number(result.changes);
      const lastInsertRowid = Number(result.lastInsertRowid);
      return {
        results: [],
        success: true,
        meta: {
          duration: 0,
          size_after: 0,
          rows_read: 0,
          rows_written: changes,
          last_row_id: lastInsertRowid,
          changed_db: changes > 0,
          changes: changes
        }
      };
    } catch (err: any) {
      console.warn(`[SQLite D1] Query error in run(): ${err.message}\nSQL: ${this.sql}`);
      throw err;
    }
  }

  async raw<T = unknown[]>(options?: { columnNames?: boolean }): Promise<any> {
    try {
      const stmt = this.db.prepare(this.sql);
      const rows = stmt.all(...this.params) as Record<string, any>[];
      const rawRows = rows.map(r => Object.values(r).map(fromSqliteValue));
      if (options?.columnNames && rows.length > 0) {
        return [Object.keys(rows[0]), ...rawRows];
      }
      return rawRows;
    } catch (err: any) {
      console.warn(`[SQLite D1] Query error in raw(): ${err.message}\nSQL: ${this.sql}`);
      throw err;
    }
  }
}

export class NodeD1Database implements D1Database {
  private transactionLock: Promise<void> = Promise.resolve();

  constructor(
    public readonly rawDb: DatabaseSync,
    public readonly dbPath?: string
  ) {}


  /**
   * Performs an immediate SQLite VACUUM and truncates the WAL write-ahead log to reclaim disk space.
   */
  vacuum(): void {
    try {
      this.rawDb.exec('VACUUM;');
      this.rawDb.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    } catch (err: unknown) {
      console.warn('[SQLite D1] VACUUM / checkpoint warning:', err);
    }
  }

  prepare(query: string): D1PreparedStatement {
    return new NodeD1PreparedStatement(this.rawDb, query) as unknown as D1PreparedStatement;
  }

  async batch<T = unknown>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]> {
    if (!statements || statements.length === 0) {
      return [];
    }

    // Queue / serialize batch transactions so concurrent async operations
    // never execute overlapping BEGIN IMMEDIATE statements on the same SQLite connection.
    const previousLock = this.transactionLock;
    let releaseLock: () => void;
    this.transactionLock = new Promise<void>((resolve) => {
      releaseLock = resolve;
    });

    await previousLock;

    try {
      this.rawDb.exec('BEGIN IMMEDIATE');
      try {
        const results: D1Result<T>[] = [];
        for (const stmt of statements) {
          const res = await stmt.run<T>();
          results.push(res);
        }
        this.rawDb.exec('COMMIT');
        return results;
      } catch (err) {
        try {
          this.rawDb.exec('ROLLBACK');
        } catch {}
        throw err;
      }
    } finally {
      releaseLock!();
    }
  }

  async exec(query: string): Promise<D1ExecResult> {
    this.rawDb.exec(query);
    return { count: 0, duration: 0 };
  }

  async dump(): Promise<ArrayBuffer> {
    throw new Error('dump() is not supported in NodeD1Database');
  }

  close(): void {
    try {
      this.rawDb.close();
    } catch {}
  }

  withSession(_constraintOrBookmark?: string): D1DatabaseSession {
    const session = Object.assign(this, {
      getBookmark: () => null
    });
    return session as unknown as D1DatabaseSession;
  }
}

/**
 * Runs all pending migrations from migrations/ directory.
 */
export function runMigrations(db: DatabaseSync, migrationsDir: string): void {
  // Ensure migrations tracking tables exist (supports both d1_migrations and _cf_d1_migrations)
  db.exec(`
    CREATE TABLE IF NOT EXISTS d1_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      applied_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS _cf_d1_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      applied_at INTEGER NOT NULL
    );
    INSERT OR IGNORE INTO d1_migrations (name, applied_at)
      SELECT name, applied_at FROM _cf_d1_migrations;
    INSERT OR IGNORE INTO _cf_d1_migrations (name, applied_at)
      SELECT name, applied_at FROM d1_migrations;
  `);

  if (!fs.existsSync(migrationsDir)) {
    console.warn(`[Migrations] Directory not found: ${migrationsDir}`);
    return;
  }

  const files = fs.readdirSync(migrationsDir)
    .filter((f: string) => f.endsWith('.sql'))
    .sort();

  const stmtGet = db.prepare('SELECT name FROM d1_migrations WHERE name = ?');
  const stmtInsertD1 = db.prepare('INSERT OR REPLACE INTO d1_migrations (name, applied_at) VALUES (?, ?)');
  const stmtInsertCf = db.prepare('INSERT OR REPLACE INTO _cf_d1_migrations (name, applied_at) VALUES (?, ?)');

  let appliedCount = 0;
  for (const file of files) {
    const existing = stmtGet.get(file);
    if (existing) continue;

    const filePath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(filePath, 'utf-8');

    console.log(`[Migrations] Applying ${file}...`);
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(sql);
      const appliedAt = Math.floor(Date.now() / 1000);
      stmtInsertD1.run(file, appliedAt);
      stmtInsertCf.run(file, appliedAt);
      db.exec('COMMIT');
      appliedCount++;
    } catch (err: any) {
      db.exec('ROLLBACK');
      console.error(`[Migrations] Failed to apply ${file}:`, err.message || err);
      throw err;
    }
  }

  if (appliedCount > 0) {
    console.log(`[Migrations] Successfully applied ${appliedCount} migration(s).`);
  } else {
    console.log('[Migrations] Database schema is up-to-date.');
  }
}

/**
 * Initializes SQLite database for Serverfull mode with WAL mode and runs pending migrations.
 */
export function initServerfullDb(dbPath: string, rootDir: string = getPackageRoot()): NodeD1Database {
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  // Seamlessly migrate legacy database from ./data/dns_worker.sqlite if target database does not exist yet
  if (!fs.existsSync(dbPath)) {
    const legacyPath = path.join(process.cwd(), 'data', 'dns_worker.sqlite');
    if (fs.existsSync(legacyPath) && path.resolve(legacyPath) !== path.resolve(dbPath)) {
      try {
        fs.copyFileSync(legacyPath, dbPath);
        console.log(`[SQLite D1] Seamlessly migrated existing database from ${legacyPath} to ${dbPath}`);
      } catch {
        /* If copy fails, fresh database will be initialized */
      }
    }
  }

  console.log(`[SQLite D1] Connecting to database at: ${dbPath}`);
  const rawDb = new DatabaseSync(dbPath);

  // Configure SQLite for high concurrency, zero-copy memory reads & integrity
  rawDb.exec('PRAGMA journal_mode = WAL;');
  rawDb.exec('PRAGMA synchronous = NORMAL;');
  rawDb.exec('PRAGMA busy_timeout = 5000;');
  rawDb.exec('PRAGMA foreign_keys = ON;');
  rawDb.exec('PRAGMA temp_store = MEMORY;');
  rawDb.exec('PRAGMA cache_size = -64000;'); // 64 MB in-memory page cache
  rawDb.exec('PRAGMA mmap_size = 268435456;'); // 256 MB zero-copy memory-mapped I/O

  // Run migrations
  const migrationsDir = path.join(rootDir, 'migrations');
  runMigrations(rawDb, migrationsDir);

  return new NodeD1Database(rawDb, dbPath);
}

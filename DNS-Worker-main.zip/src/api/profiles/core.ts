import { Env, User, Profile, ProfileSettings, ExecutionContext } from "../../types";
import { ProfileModel } from "../../models/profile";
import { ListModel } from "../../models/list";
import { LogModel } from "../../models/log";
import { generateId } from "../../lib/auth";
import { isSafeUrl } from "../../utils/validator";
import { buildDNSQuery, parseDNSAnswer } from "../../utils/dns";
import { resolveClientGeoCountry } from "../../utils/geoip";
import { pipeline } from "../../pipeline";
import { PROFILE_NAME_REGEX } from "../../utils/validator";
import { getDefaultUpstreamUrl, getDefaultProfileFilterUrls } from "../../constants/presets";
import { syncAllListsForProfile } from "../../utils/sync";

/**
 * Handle requests to /api/profiles (without specific profile ID)
 */
export async function handleProfilesCoreCollectionRequest(
  request: Request,
  env: Env,
  user: User,
  pathParts: string[],
  ctx?: ExecutionContext
): Promise<Response> {
  const profileModel = new ProfileModel(env.DB);

  // GET /api/profiles
  if (request.method === 'GET') {
    const results = await profileModel.listByOwner(user.id);
    return new Response(JSON.stringify(results), { headers: { 'Content-Type': 'application/json' } });
  }

  // POST /api/profiles
  if (request.method === 'POST') {
    const body = await request.json() as { name: string };
    
    if (!body.name || !PROFILE_NAME_REGEX.test(body.name)) {
      return new Response("Invalid Profile Name format", { status: 400 });
    }

    const existingProfiles = await profileModel.listByOwner(user.id);
    const maxProfiles = Number(env.MAX_PROFILES_PER_USER) || 10;
    if (existingProfiles.length >= maxProfiles) return new Response(`Profile limit exceeded (max ${maxProfiles})`, { status: 400 });

    const existing = existingProfiles.find(p => p.name === body.name);
    if (existing) return new Response("The profile name already exists", { status: 400 });

    const newId = generateId(6);
    const globalMaxRetention = env.MAX_LOG_RETENTION_DAYS !== undefined && env.MAX_LOG_RETENTION_DAYS !== ''
      ? Number(env.MAX_LOG_RETENTION_DAYS)
      : 30;
    const adminDefaultRetention = env.DEFAULT_LOG_RETENTION_DAYS !== undefined && env.DEFAULT_LOG_RETENTION_DAYS !== ''
      ? Math.min(Number(env.DEFAULT_LOG_RETENTION_DAYS), globalMaxRetention)
      : Math.min(7, globalMaxRetention);
    const normalUserMaxRetention = env.NORMAL_USER_MAX_LOG_RETENTION_DAYS !== undefined && env.NORMAL_USER_MAX_LOG_RETENTION_DAYS !== ''
      ? Math.min(Number(env.NORMAL_USER_MAX_LOG_RETENTION_DAYS), globalMaxRetention)
      : Math.min(7, globalMaxRetention);
    const normalUserDefaultRetention = env.NORMAL_USER_DEFAULT_LOG_RETENTION_DAYS !== undefined && env.NORMAL_USER_DEFAULT_LOG_RETENTION_DAYS !== ''
      ? Math.min(Number(env.NORMAL_USER_DEFAULT_LOG_RETENTION_DAYS), normalUserMaxRetention)
      : Math.min(1, normalUserMaxRetention);

    const defaultRetentionDays = user?.role === 'admin' ? adminDefaultRetention : normalUserDefaultRetention;
    const defaultUpstream = getDefaultUpstreamUrl(env);
    const defaultSettings: ProfileSettings = {
      upstream: [defaultUpstream],
      ecs: { enabled: true, use_client_ip: true },
      log_retention_days: defaultRetentionDays,
      skip_log_on_pass: false,
      default_policy: 'ALLOW',
      best_effort_ech: { enabled: false, fronting_domain: "cloudflare-ech.com" }
    };
    await profileModel.create({ id: newId, owner_id: user.id, name: body.name || "Unnamed Profile", settings: defaultSettings });

    // Automatically inherit active account-level E2EE keys if configured
    try {
      const existingLogKey = await env.DB.prepare(
        "SELECT public_key, is_active FROM user_log_keys WHERE profile_id IN (SELECT id FROM profiles WHERE owner_id = ?) LIMIT 1"
      )
        .bind(user.id)
        .first<{ public_key: string; is_active?: number }>();

      if (existingLogKey?.public_key) {
        const now = Math.floor(Date.now() / 1000);
        await env.DB.prepare(
          "INSERT INTO user_log_keys (profile_id, public_key, created_at, is_active) VALUES (?, ?, ?, ?)"
        )
          .bind(newId, existingLogKey.public_key, now, existingLogKey.is_active ?? 1)
          .run();

        const existingRecKey = await env.DB.prepare(
          "SELECT encrypted_sk, iv, salt FROM user_recovery_wrapped_keys WHERE profile_id IN (SELECT id FROM profiles WHERE owner_id = ?) LIMIT 1"
        )
          .bind(user.id)
          .first<{ encrypted_sk: string; iv: string; salt: string }>();

        if (existingRecKey) {
          await env.DB.prepare(
            "INSERT INTO user_recovery_wrapped_keys (profile_id, encrypted_sk, iv, salt, created_at) VALUES (?, ?, ?, ?, ?)"
          )
            .bind(newId, existingRecKey.encrypted_sk, existingRecKey.iv, existingRecKey.salt, now)
            .run();
        }
      }
    } catch (e) {
      console.error("[Profiles] Failed to inherit E2EE log key for new profile:", e);
    }

    // Attach default filter lists to the profile if configured
    let listsAttached = false;
    try {
      const defaultFilterUrls = getDefaultProfileFilterUrls(env);
      if (defaultFilterUrls.length > 0) {
        const listModel = new ListModel(env.DB);
        await listModel.addListsBulk(newId, defaultFilterUrls);
        listsAttached = true;
      }
    } catch (listErr) {
      console.warn(`[Profiles] Failed to attach default filter lists to profile ${newId}:`, listErr);
    }

    if (listsAttached && ctx) {
      ctx.waitUntil(
        syncAllListsForProfile(newId, env, ctx).catch((err) => {
          console.error(`[Profiles] Background sync failed for profile ${newId}:`, err);
        })
      );
    }

    return new Response(JSON.stringify({ id: newId }), { status: 201 });
  }

  return new Response("Method Not Allowed", { status: 405 });
}

/**
 * Handle core requests to /api/profiles/:id
 */
export async function handleProfilesCoreRequest(
  request: Request,
  env: Env,
  user: User | null,
  profile: Profile,
  pathParts: string[],
  ctx: ExecutionContext
): Promise<Response> {
  const profileModel = new ProfileModel(env.DB);
  const logModel = new LogModel(env.DB);
  const profileId = profile.id;

  // Handles:
  // - DELETE /api/profiles/:id
  // - PATCH /api/profiles/:id (updateName)
  // - GET /api/profiles/:id
  if (pathParts.length === 3) {
    if (request.method === 'DELETE') {
      await profileModel.delete(profileId);
      return new Response(null, { status: 204 });
    }

    if (request.method === 'PATCH') {
      const { name } = await request.json() as { name: string };
      if (!name || !PROFILE_NAME_REGEX.test(name)) return new Response("Invalid Profile Name format", { status: 400 });
      await profileModel.updateName(profileId, name);
      ctx.waitUntil(pipeline.clearCache(profileId, true, env));
      return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json' } });
    }

    if (request.method === 'GET') {
      return new Response(JSON.stringify(profile), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response("Method Not Allowed", { status: 405 });
  }

  // POST /api/profiles/:id/rotate_key
  if (pathParts[3] === 'rotate_key' && request.method === 'POST') {
    const newKey = generateId(12);
    await profileModel.rotateKey(profileId, newKey);
    ctx.waitUntil(pipeline.clearCache(profileId, false, env));
    return new Response(JSON.stringify({ profile_key: newKey }), { headers: { 'Content-Type': 'application/json' } });
  }

  // PATCH /api/profiles/:id/settings
  if (pathParts[3] === 'settings' && request.method === 'PATCH') {
    const newSettings = await request.json() as ProfileSettings;
    
    // Enforce log retention limit
    const globalMaxRetention = env.MAX_LOG_RETENTION_DAYS !== undefined && env.MAX_LOG_RETENTION_DAYS !== ''
      ? Number(env.MAX_LOG_RETENTION_DAYS)
      : 30;
    const adminMaxRetention = env.ADMIN_USER_MAX_LOG_RETENTION_DAYS !== undefined && env.ADMIN_USER_MAX_LOG_RETENTION_DAYS !== ''
      ? Math.min(Number(env.ADMIN_USER_MAX_LOG_RETENTION_DAYS), globalMaxRetention)
      : globalMaxRetention;
    const normalUserMax = env.NORMAL_USER_MAX_LOG_RETENTION_DAYS !== undefined && env.NORMAL_USER_MAX_LOG_RETENTION_DAYS !== ''
      ? Math.min(Number(env.NORMAL_USER_MAX_LOG_RETENTION_DAYS), globalMaxRetention)
      : Math.min(7, globalMaxRetention);
    const userMaxRetention = user?.role === 'admin' ? adminMaxRetention : normalUserMax;

    if (newSettings.log_retention_days != null) {
      newSettings.log_retention_days = Math.min(Number(newSettings.log_retention_days), userMaxRetention);
    }
    
    if (newSettings.upstream && Array.isArray(newSettings.upstream)) {
      for (const url of newSettings.upstream) {
        // 允许三种格式：https://...、http://...、tcp://...、裸 IP（8.8.8.8）或 IP:port（8.8.8.8:5353）
        // resolver.ts 中裸 IP 已被视为经典 TCP DNS，API 验证层对齐此行为。
        const isHttps = url.startsWith('https://');
        const isHttp  = url.startsWith('http://');
        const isTcp   = url.startsWith('tcp://');
        const isTls   = url.startsWith('tls://');
        const isDot   = url.startsWith('dot://');
        const isUdp   = url.startsWith('udp://');
        const isSdns  = url.startsWith('sdns://');
        // 裸 host[:port]：不含 / 且不含 scheme
        const isBareHost = !url.includes('//') && !url.startsWith('/');

        if (!isHttps && !isHttp && !isTcp && !isTls && !isDot && !isUdp && !isSdns && !isBareHost) {
          return new Response("Invalid upstream URL format. Only HTTP(S), TCP, TLS (DoT), DNS Stamp (sdns://), or bare host[:port] are allowed.", { status: 400 });
        }
        // 统一规范化后做安全检查（防 SSRF）
        const normalized = isBareHost ? `tcp://${url}` : url;
        if (!isSafeUrl(normalized)) {
          return new Response("Invalid upstream URL. Private networks and localhosts are not allowed.", { status: 400 });
        }
      }
    }

    // 检查旧配置中的 log_retention_days
    const oldProfile = await profileModel.getById(profileId);
    let oldDays = 30;
    try {
      const oldSettings = JSON.parse(oldProfile?.settings || "{}");
      if (oldSettings?.log_retention_days != null) {
        oldDays = Number(oldSettings.log_retention_days);
      }
    } catch {}

    await profileModel.updateSettings(profileId, newSettings);

    // 仅在显式缩短日志留存期时触发主动清理，避免每次保存设置无谓执行 DELETE
    const newDays = newSettings.log_retention_days;
    if (newDays != null && Number(newDays) < oldDays) {
      if (Number(newDays) === 0) {
        // 关闭日志时彻底清空当前配置的历史日志
        ctx.waitUntil((async () => {
          try {
            await env.DB.batch([
              env.DB.prepare("DELETE FROM logs WHERE profile_id = ?").bind(profileId),
              env.DB.prepare("DELETE FROM hourly_rollups WHERE profile_id = ?").bind(profileId)
            ]);
            await logModel.kemKeys.cleanupProfileOrphans(profileId);
          } catch (e: any) {
            console.error("[Profile] Failed to purge logs on retention disable:", e?.message || e);
          }
        })());
      } else {
        const threshold = Math.floor(Date.now() / 1000 - (Number(newDays) * 24 * 3600));
        ctx.waitUntil(logModel.cleanup(profileId, threshold));
      }
    }

    // 设置变更仅清除配置缓存，保留 2.5MB 布隆过滤器缓存
    ctx.waitUntil(pipeline.clearCache(profileId, false, env));
    return new Response(JSON.stringify({ success: true }), { headers: { 'Content-Type': 'application/json' } });
  }

  // POST /api/profiles/:id/test
  if (pathParts[3] === 'test' && request.method === 'POST') {
    const { domain, type } = await request.json() as { domain: string, type: string };
    const rawQuery = buildDNSQuery(domain, type);
    const result = await pipeline.process(request, { name: domain, type, raw: rawQuery }, { profileId, startTime: Date.now(), env, ctx });
    return new Response(JSON.stringify({
      action: result.action,
      reason: result.reason,
      answers: result.answer.length > 0 ? parseDNSAnswer(result.answer) : [],
      diagnostics: result.diagnostics,
      latency: result.latency,
      timings: result.timings,
      client_ip: request.headers.get("CF-Connecting-IP") || "127.0.0.1",
      geo_country: await resolveClientGeoCountry(request, request.headers.get("CF-Connecting-IP") || "127.0.0.1"),
      success: true 
    }), { headers: { 'Content-Type': 'application/json' } });
  }

  return new Response("Not Found", { status: 404 });
}

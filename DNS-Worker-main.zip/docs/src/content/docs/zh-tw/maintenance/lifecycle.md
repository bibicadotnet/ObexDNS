---
title: 資料留存、維護任務與生命週期
description: 查詢日誌保留上限、30 天不活躍賬號自動清理機制、批次寫入最佳化與維護環境變數手冊。
sidebar:
  order: 1
---

為了在可追溯審計、使用者隱私保護與長期儲存效能之間取得最佳平衡，DNS Worker 內建了全自動的生命週期管理引擎。本文件闡述日誌保留上限策略、後臺整理維護與相關環境變數。

---

## 1. 查詢日誌保留策略與隱私合規

### 最大保留硬性上限 (`MAX_LOG_RETENTION_DAYS`)
查詢日誌的保留天數受管理員設定的 `MAX_LOG_RETENTION_DAYS` 上限約束（Serverless D1 預設 **30 天**，Serverfull 模式預設 **360 天**）。
- **隱私最小化原則**：DNS 解析記錄涉及高度敏感的個人行為軌跡，通過靈活可控的留存上限平衡審計合規與個人隱私。
- **資料庫效能保障**：將日誌控制在合理體量，可確保 SQLite 索引常駐記憶體，防止隨著使用時間推移導致解析延遲劣變或空間耗盡。

### 30 天無解析活動自動清理 (Inactivity Purge)
為了避免長期閒置的廢棄接入點持續佔用寶貴的磁碟與資料庫空間：
- 若某個賬號在 **連續 30 天** 內未產生任何 DNS 解析流量，其歷史查詢日誌將被自動清空。
- **配置完整保留**：賬號主體資訊、自定義黑白名單、接入點金鑰及各類個性化設定完全保留，僅清理歷史日誌流水。

---

## 2. 後臺自動化維護任務

DNS Worker 定期執行週期性資料庫整理：

```mermaid
flowchart TD
    subgraph Maintenance["周期性定时运维阶段"]
        direction TB
        M1["1. 清理超出设定保留天数的历史日志"]
        M2["2. 检索并清理连续 30 天不活跃账号的历史日志"]
        M3["3. 作废并清理过期的 Web 登录 Session 与 Refresh 凭据"]
        M4["4. 执行 SQLite WAL 检查点整理与 VACUUM 空间压缩"]
        M1 --> M2 --> M3 --> M4
    end
```

- **Cloudflare Workers 模式**：通過 Cloudflare Cron Triggers（`scheduled(event, env, ctx)` 入口）定時觸發。
- **獨立伺服器模式 (Serverfull Node.js / Bun)**：由程序內建的高精度定時排程器常駐排程。

---

## 3. 日誌批處理緩衝器 (Log Batcher)

若每產生一次 DNS 解析就同步執行一次資料庫 `INSERT`，在高併發下會導致極高 I/O 阻塞。DNS Worker 採用了記憶體佇列批次提交機制：

- 解析完成的日誌先推入高併發記憶體佇列。
- 當積壓條數達到閾值（`LOG_BATCH_SIZE`）或時間到達視窗（`LOG_FLUSH_INTERVAL_MS`）時，單次事務批次寫入資料庫。
- 記憶體佇列設有背壓保護上限，杜絕流量突增引發的記憶體溢位。

---

---

## 4. 維護與配額差異對比：Serverless 與 Serverfull

由於 Cloudflare D1 資料庫具有嚴格的儲存容量（免費版 500 MB）與每日寫入額度限制（100,000 次），而 Serverfull 模式基於本地物理硬碟/SSD 執行，兩者的日誌保留上限與刪除配額經過了針對性的差異化調優：

| 維護引數 | Serverless (`wrangler.toml`) | Serverfull (`.env.serverfull`) | 差異原因與配額考量 |
| :--- | :--- | :--- | :--- |
| **管理員最長保留** (`MAX_LOG_RETENTION_DAYS`) | **30 天** | **360 天** | 保護邊緣 D1 免受儲存耗盡；在 Serverfull 模式下支援完整年度審計。 |
| **管理員預設保留** (`DEFAULT_LOG_RETENTION_DAYS`) | **7 天** | **180 天** | 物理磁碟擁有充裕儲存，預設提供更長審計週期。 |
| **普通使用者最長保留** (`NORMAL_USER_MAX_LOG_RETENTION_DAYS`) | **7 天** | **30 天** | 限制多租戶場景下普通成員日誌對總容量的消耗。 |
| **普通使用者預設保留** (`NORMAL_USER_DEFAULT_LOG_RETENTION_DAYS`) | **1 天** | **7 天** | 最小化多使用者共享環境的初始資料沉澱。 |
| **單配置最大日誌行數** (`MAX_LOGS_PER_PROFILE`) | **500,000 行** | **5,000,000 行** | 防止單接入點瞬時高頻解析導致資料庫熔斷崩潰。 |
| **單次批次清理上限** (`LOG_CLEANUP_BATCH_LIMIT`) | `1000` 行/輪 | `1000` 行/輪 | 避免 Cron 定時清理單次耗時過長觸發執行超時。 |
| **每日清理最大刪除配額** (`LOG_CLEANUP_DAILY_BUDGET`) | `20,000` 行/天 | `20,000` 行/天 | 預留 80% 寫入預算給正常業務，不耗盡 D1 免費額度。 |
| **賬號閒置廢棄閾值** (`INACTIVITY_THRESHOLD_DAYS`) | `180` 天 | `180` 天 | 判定長期廢棄休眠賬號的期限。 |
| **閒置日誌自動清空** | **30 天** | **30 天** | 連續 30 天無解析流量即清空歷史日誌釋放資源。 |

---

## 5. 維護環境變數參考手冊

### 留存與儲存配額變數

#### `MAX_LOG_RETENTION_DAYS` 與 `DEFAULT_LOG_RETENTION_DAYS`
- **支援模式**：Serverless 與 Serverfull
- **預設配置**：
  - `wrangler.toml`：上限 `30` 天，預設 `7` 天
  - `.env.serverfull`：上限 `360` 天，預設 `180` 天
- **說明**：超級管理員配置方案的日誌最長留存天數與預設配置週期。

#### `NORMAL_USER_MAX_LOG_RETENTION_DAYS` 與 `NORMAL_USER_DEFAULT_LOG_RETENTION_DAYS`
- **支援模式**：Serverless 與 Serverfull
- **預設配置**：
  - `wrangler.toml`：上限 `7` 天，預設 `1` 天
  - `.env.serverfull`：上限 `30` 天，預設 `7` 天
- **說明**：針對受限普通使用者的日誌留存週期與配額。

#### `MAX_LOGS_PER_PROFILE`
- **支援模式**：Serverless 與 Serverfull
- **預設值**：Serverless 為 `500000`（50 萬行），Serverfull 為 `5000000`（500 萬行）。
- **說明**：單配置日誌儲存行數硬上限，充當流量突發時的斷路保護器。

---

### 定時任務與會話生命週期變數

#### `LOG_CLEANUP_BATCH_LIMIT` 與 `LOG_CLEANUP_DAILY_BUDGET`
- **預設值**：單批次 `1000` 行，每日上限 `20000` 行
- **說明**：精確調控定時維護任務的刪除吞吐量，確保平穩執行在底層資料庫事務配額安全線內。

#### `DEFAULT_SESSION_EXPIRATION_MINUTES` 與 `OPTIONAL_SESSION_EXPIRATION_DAYS`
- **預設值**：預設登入態 `1440` 分鐘（24 小時），勾選“保持登入”為 `7` 天
- **說明**：Web 儀表盤操作會話有效期。

#### `ACCESS_TOKEN_EXPIRATION_MINUTES` 與 `RTR_GRACE_WINDOW_MS`
- **預設值**：Access Token 為 `1` 分鐘，RTR 併發容錯視窗為 `15000` 毫秒（15 秒）
- **說明**：零信任憑據輪換引數，有效杜絕憑據重用，同時兼顧瀏覽器多標籤頁平滑過渡。

#### `AUTO_VACUUM` 與 `SQLITE_JOURNAL_MODE` *(僅 Serverfull)*
- **預設值**：`WAL`（預寫日誌模式）
- **說明**：本地 SQLite 引擎儲存引數，保障高併發讀寫效能與崩潰自愈韌性。

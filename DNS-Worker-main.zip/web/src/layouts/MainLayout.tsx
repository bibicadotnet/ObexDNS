import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  Edit3,
  BarChart3,
  Clock,
  Download,
  ListFilter,
} from "lucide-react";
import { useParams } from "react-router-dom";
import { useIsMobile } from "../hooks/useIsMobile";
import type { Profile, UserInfo } from "../types/auth";
import { DesktopSidebar } from "./DesktopSidebar";
import { HeaderNavbar } from "./HeaderNavbar";
import { MobileBottomNav } from "./MobileBottomNav";

/**
 * Properties for the MainLayout component.
 */
interface MainLayoutProps {
  /** The child route views to render. */
  children: React.ReactNode;
  /** True if desktop sidebar is expanded. */
  isSidebarOpen: boolean;
  /** Callback to set desktop sidebar expand/collapse state. */
  setIsSidebarOpen: (open: boolean) => void;
  /** Current active UI theme. */
  theme: "light" | "dark" | "system";
  /** Callback to set UI theme. */
  setTheme: (theme: "light" | "dark" | "system") => void;
  /** Selected Profile object. */
  selectedProfile: Profile | null;
  /** Available profiles list. */
  profiles: Profile[];
  /** Callback to set selected Profile. */
  setSelectedProfile: (p: Profile) => void;
  /** Router location object. */
  location: any;
  /** Router navigation function. */
  navigate: (path: string) => void;
  /** Callback to handle logouts. */
  handleLogout: () => void;
  /** Current logged in user info. */
  currentUser: UserInfo | null;
  /** True if a background saving operation is active. */
  isSaving?: boolean;
}

/**
 * MainLayout component establishes the page template framing for all authenticated views.
 * It dynamically alternates between Sidebar layout (for desktops) and Bottom Tab layout (for mobile devices).
 *
 * @param props - Component props containing shared state hooks and layout controllers.
 * @returns React elements representing the page layout template.
 */
export const MainLayout = ({
  children,
  isSidebarOpen,
  setIsSidebarOpen,
  theme,
  setTheme,
  selectedProfile,
  profiles,
  setSelectedProfile,
  location,
  navigate,
  handleLogout,
  currentUser,
  isSaving,
}: MainLayoutProps) => {
  const { profileId: urlProfileId } = useParams();
  const isMobile = useIsMobile();
  const { t } = useTranslation();
  const activeId = urlProfileId || selectedProfile?.id;
  const isProfileActive = !!activeId;

  useEffect(() => {
    if (
      urlProfileId &&
      profiles.length > 0 &&
      selectedProfile?.id !== urlProfileId
    ) {
      const found = profiles.find((p: Profile) => p.id === urlProfileId);
      if (found) setSelectedProfile(found);
    }
  }, [urlProfileId, profiles, selectedProfile, setSelectedProfile]);

  const navItems = [
    {
      id: "setup",
      label: t("nav.setup"),
      icon: <Download size={20} />,
      path: `/dash/${activeId}/setup`,
    },
    {
      id: "rules",
      label: isMobile && location.pathname.includes("/filter") ? t("nav.filter") : t("nav.rules"),
      icon: isMobile && location.pathname.includes("/filter") ? <ListFilter size={20} /> : <Edit3 size={20} />,
      path: isMobile && location.pathname.includes("/filter")
        ? `/dash/${activeId}/filter`
        : `/dash/${activeId}/rules`,
    },
    {
      id: "stats",
      label: t("nav.stats"),
      icon: <BarChart3 size={20} />,
      path: `/dash/${activeId}/stats`,
    },
    {
      id: "logs",
      label: t("nav.logs"),
      icon: <Clock size={20} />,
      path: `/dash/${activeId}/logs`,
    },
  ];

  return (
    <div className="flex h-screen w-full bg-white dark:bg-gray-950 overflow-hidden flex-col md:flex-row">

      {!isMobile && (
        <DesktopSidebar
          isSidebarOpen={isSidebarOpen}
          setIsSidebarOpen={setIsSidebarOpen}
          isProfileActive={isProfileActive}
          activeId={activeId}
          location={location}
          navigate={navigate}
          handleLogout={handleLogout}
          currentUser={currentUser}
          navItems={navItems}
        />
      )}

      <main className="flex-1 min-w-0 h-full relative bg-gray-50/20 dark:bg-gray-950/20 flex flex-col overflow-hidden">
        {/* Top Header Navbar */}
        <HeaderNavbar
          theme={theme}
          setTheme={setTheme}
          selectedProfile={selectedProfile}
          isProfileActive={isProfileActive}
          location={location}
          navigate={navigate}
          isSaving={isSaving}
          currentUser={currentUser}
        />

        {/* Page Content */}
        <div className="flex-1 min-h-0 flex flex-col relative z-0 isolate" style={{ isolation: "isolate" }}>
          {location.pathname.endsWith("/logs") ? (
            <div className="flex-1 overflow-y-auto">{children}</div>
          ) : (
            <div className="flex-1 overflow-y-auto pt-14">
              <div className="p-2 md:p-4 pb-24 md:pb-8">{children}</div>
            </div>
          )}
        </div>

        {/* Mobile Bottom Navigation Bar */}
        {isMobile && (
          <MobileBottomNav
            isProfileActive={isProfileActive}
            navItems={navItems}
            location={location}
            navigate={navigate}
          />
        )}
      </main>
    </div>
  );
};

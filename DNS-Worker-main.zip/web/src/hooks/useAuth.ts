import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import type { OverlayToaster } from "@blueprintjs/core";
import { getAccessToken, setAccessToken } from "../utils/token";
import { setSystemTimeZone, setSystemLocale } from "../utils/date";
import { refresh, getMe, logout, ApiError, e2ee } from "../services";
import type { UserInfo } from "../services";

/**
 * Helper to clear the CSRF cookie and session storage flags.
 */
const clearCsrfToken = () => {
  const secureFlag = typeof window !== "undefined" && window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `csrf_token=; Max-Age=0; path=/; SameSite=Lax${secureFlag}`;
  try {
    sessionStorage.removeItem("obex_session_active");
    sessionStorage.removeItem("obex_session_locked");
    sessionStorage.removeItem("obex_username");
    sessionStorage.removeItem("obex_user_id");
    localStorage.removeItem("obex_username");
    localStorage.removeItem("obex_user_id");
  } catch {}
};

/**
 * Custom hook managing authentication, current user details, and global unauthorized events.
 *
 * @param toasterRef - Ref to the Blueprint OverlayToaster to show authorization errors.
 */
export function useAuth(toasterRef: React.RefObject<OverlayToaster | null>) {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null);
  const [currentUser, setCurrentUser] = useState<UserInfo | null>(null);
  const { t, i18n } = useTranslation();

  const checkAuth = async () => {
    try {
      const token = getAccessToken();
      const hasCsrfToken = document.cookie.includes("csrf_token=");

      // Only bail out if we neither have an in-memory token nor a csrf token cookie.
      if (!token && !hasCsrfToken) {
        setIsLoggedIn(false);
        return;
      }

      // If we don't have an access token in memory, try to refresh first.
      if (!token) {
        try {
          const data = await refresh();
          setAccessToken(data.accessToken);
          if (data.user?.id) {
            sessionStorage.setItem("obex_user_id", data.user.id);
            try { localStorage.setItem("obex_user_id", data.user.id); } catch {}
          }
          if (data.user?.username) {
            sessionStorage.setItem("obex_username", data.user.username);
            try { localStorage.setItem("obex_username", data.user.username); } catch {}
          }
        } catch {
          clearCsrfToken();
          setIsLoggedIn(false);
          return;
        }
      }

      // Fetch user data (uses token automatically via fetch interceptor).
      try {
        const meData = await getMe();
        setCurrentUser(meData);
        if (meData.username) {
          sessionStorage.setItem("obex_username", meData.username);
          try { localStorage.setItem("obex_username", meData.username); } catch {}
        }
        if (meData.id) {
          sessionStorage.setItem("obex_user_id", meData.id);
          try { localStorage.setItem("obex_user_id", meData.id); } catch {}
        }

        if (meData.timezone) {
          setSystemTimeZone(meData.timezone);
        }
        if (meData.locale) {
          setSystemLocale(meData.locale);
          i18n.changeLanguage(meData.locale);
        }
        setIsLoggedIn(true);
      } catch (err: any) {
        if (err instanceof ApiError && err.status === 403 && err.bodyText === "session_paused") {
          setIsLoggedIn(true);
          // Ensure user context is restored for lock screen even when paused
          try {
            const activeToken = getAccessToken();
            if (activeToken) {
              const base64Url = activeToken.split(".")[1];
              const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
              const payload = JSON.parse(atob(base64));
              if (payload?.userId) {
                sessionStorage.setItem("obex_user_id", payload.userId);
                try { localStorage.setItem("obex_user_id", payload.userId); } catch {}
                const cachedUsername = sessionStorage.getItem("obex_username") || localStorage.getItem("obex_username") || "";
                setCurrentUser({
                  id: payload.userId,
                  username: cachedUsername,
                  role: payload.role || "user",
                  pin_enabled: true
                });
              }
            }
          } catch {}
          window.dispatchEvent(new Event("session_paused"));
          return;
        }
        if (err instanceof ApiError && err.status === 401) {
          clearCsrfToken();
        }
        setIsLoggedIn(false);
      }
    } catch {
      setIsLoggedIn(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  // Listen for user profile/security updates (e.g. PIN configured/removed)
  useEffect(() => {
    const handleUserUpdated = async () => {
      try {
        const meData = await getMe();
        setCurrentUser(meData);
      } catch (e) {
        console.warn("Failed to refresh user on user_updated event", e);
      }
    };

    window.addEventListener("user_updated", handleUserUpdated);
    return () => {
      window.removeEventListener("user_updated", handleUserUpdated);
    };
  }, []);

  // Listen for unauthorized events from the API client / interceptor
  useEffect(() => {
    const handleUnauthorized = (e: Event) => {
      e2ee.clearStorage();
      clearCsrfToken();
      setIsLoggedIn(false);

      const customEvent = e as CustomEvent<{ reason?: string }>;
      const reason = customEvent.detail?.reason;

      if (reason === "missing") {
        return;
      }

      let message = t("auth.unauthorizedDefault");
      if (reason === "geolocation_mismatch" || reason === "geolocation_missing") {
        message = t("auth.unauthorizedGeo");
      } else if (reason === "expired") {
        message = t("auth.unauthorizedExpired");
      } else if (reason === "token_reuse") {
        message = t("auth.unauthorizedReuse");
      } else if (reason === "session_not_found") {
        message = t("auth.unauthorizedRevoked");
      }

      if (toasterRef.current) {
        toasterRef.current.show({
          message,
          intent: "danger",
          icon: "error",
          timeout: 5000,
        });
      }
    };

    window.addEventListener("auth_unauthorized", handleUnauthorized);
    return () => {
      window.removeEventListener("auth_unauthorized", handleUnauthorized);
    };
  }, [t, toasterRef]);

  const handleLogout = async () => {
    try {
      e2ee.clearStorage();
      await logout();
    } catch (e) {
      console.error("Logout failed", e);
    } finally {
      e2ee.clearStorage();
      if (typeof window !== "undefined" && "caches" in window) {
        try {
          await caches.delete("dns-worker-logs-v1");
        } catch {}
      }
      try {
        sessionStorage.removeItem("dns_worker_session_active");
      } catch {}
      clearCsrfToken();
      setIsLoggedIn(false);
      window.location.reload();
    }
  };

  return {
    isLoggedIn,
    currentUser,
    checkAuth,
    handleLogout,
  };
}
